#!/usr/bin/env python3
"""Prometheus Obfuscator - Interactive TUI"""

import curses, subprocess, os, json, tempfile, copy

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
PRESETS_FILE = os.path.join(SCRIPT_DIR, "custom_presets.json")

# ── 所有可用 Steps 及说明 ──────────────────────────────────────────────────────
ALL_STEPS = [
    ("Vmify",                "虚拟机化，最强混淆，性能损耗高"),
    ("EncryptStrings",       "加密字符串常量"),
    ("AntiTamper",           "防篡改校验，防止修改代码"),
    ("ConstantArray",        "将常量提取到数组中"),
    ("NumbersToExpressions", "将数字转换为表达式"),
    ("WrapInFunction",       "将代码包裹在函数中"),
    ("ProxifyLocals",        "将局部变量代理化"),
    ("SplitStrings",         "拆分字符串"),
    ("AddVararg",            "添加可变参数混淆"),
]

STEP_DEFAULTS = {
    "Vmify":                {},
    "EncryptStrings":       {},
    "AntiTamper":           {"UseDebug": False},
    "ConstantArray":        {"Threshold": 1, "StringsOnly": True, "Shuffle": True, "Rotate": True, "LocalWrapperThreshold": 0},
    "NumbersToExpressions": {},
    "WrapInFunction":       {},
    "ProxifyLocals":        {},
    "SplitStrings":         {},
    "AddVararg":            {},
}

BUILTIN_STEPS = {
    "Minify":  [],
    "Weak":    ["Vmify", "ConstantArray", "WrapInFunction"],
    "Medium":  ["EncryptStrings", "AntiTamper", "Vmify", "ConstantArray", "NumbersToExpressions", "WrapInFunction"],
    "Strong":  ["Vmify", "EncryptStrings", "AntiTamper", "Vmify", "ConstantArray", "NumbersToExpressions", "WrapInFunction"],
}

PRESETS      = ["Minify", "Weak", "Medium", "Strong"]
LUA_VERSIONS = ["Lua51", "LuaU"]
NAME_GENS    = ["MangledShuffled", "Mangled", "Il"]

NAME_GEN_DESC = {
    "MangledShuffled": "乱序混淆变量名（推荐）",
    "Mangled":         "简单混淆变量名",
    "Il":              "使用 I/l 难以区分的变量名",
}

def load_custom_presets():
    if os.path.isfile(PRESETS_FILE):
        try:
            return json.load(open(PRESETS_FILE))
        except Exception:
            pass
    return {}

def save_custom_presets(presets):
    json.dump(presets, open(PRESETS_FILE, "w"), ensure_ascii=False, indent=2)

custom_presets = load_custom_presets()

state = {
    "source":      "",
    "out":         "",
    "preset":      "Medium",
    "lua_version": "Lua51",
    "pretty":      False,
    "seed":        0,
    "name_gen":    "MangledShuffled",
    "var_prefix":  "",
    "watermark":   False,
    "wm_content":  "Obfuscated with Prometheus",
    "wm_var":      "_WATERMARK",
    "custom_steps":  None,   # None = 跟随预设；list = 自定义
    "anti_envlog":   False,
}

ANTI_ENVLOG_CODE = '''local REVEAL_HINT_STACK = false
local ANTI_ENV_LOG_MESSAGE =
[[
    loser
]]
if not getmetatable or not setmetatable or not type or not select or type(select(2, pcall(getmetatable, setmetatable({}, {__index = function(self, ...) while true do end end})))['__index']) ~= 'function' or not pcall or not debug or not rawget or not rawset or not pcall(rawset,{}," "," ") or not select or not getfenv or select(1, pcall(getfenv, 69)) == true or not select(2, pcall(rawget, debug, "info")) or #(((select(2, pcall(rawget, debug, "info")))(getfenv, "n")))<=1 or #(((select(2, pcall(rawget, debug, "info")))(print, "n")))<=1 or not (select(2, pcall(rawget, debug, "info")))(print, "s") == "[C]" or not (select(2, pcall(rawget, debug, "info")))(require, "s") == "[C]" or (select(2, pcall(rawget, debug, "info")))((function()end), "s") == "[C]" then
  return REVEAL_HINT_STACK and tostring(ANTI_ENV_LOG_MESSAGE) or nil
end
'''

# ── colors ────────────────────────────────────────────────────────────────────

def init_colors():
    curses.start_color(); curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_CYAN,    -1)   # header / accent
    curses.init_pair(2, curses.COLOR_WHITE,   -1)   # values
    curses.init_pair(3, curses.COLOR_GREEN,   -1)   # on / ok
    curses.init_pair(4, curses.COLOR_RED,     -1)   # off / err
    curses.init_pair(5, curses.COLOR_MAGENTA, -1)   # highlight label
    curses.init_pair(6, curses.COLOR_BLACK,   curses.COLOR_CYAN)  # selected

C_HEAD = lambda: curses.color_pair(1) | curses.A_BOLD
C_VAL  = lambda: curses.color_pair(2)
C_ON   = lambda: curses.color_pair(3) | curses.A_BOLD
C_OFF  = lambda: curses.color_pair(4)
C_SEL  = lambda: curses.color_pair(6) | curses.A_BOLD

def S(win, y, x, text, attr=0):
    h, w = win.getmaxyx()
    if y < 0 or y >= h or x < 0: return
    try: win.addstr(y, x, text[:max(0, w-x-1)], attr)
    except curses.error: pass

# ── generic helpers ───────────────────────────────────────────────────────────

def draw_header(win):
    S(win, 0, 0, "┌─────────────────────────────────────────┐", C_HEAD())
    S(win, 1, 0, "│  ⚡ Prometheus Obfuscator  TUI           │", C_HEAD())
    S(win, 2, 0, "└─────────────────────────────────────────┘", C_HEAD())

def prompt(stdscr, label, default=""):
    h, w = stdscr.getmaxyx()
    curses.echo(); curses.curs_set(1)
    S(stdscr, h-2, 0, " "*(w-1))
    S(stdscr, h-2, 0, f"{label}: ", C_HEAD())
    stdscr.refresh()
    val = stdscr.getstr(h-2, len(label)+2, 200).decode("utf-8", errors="replace").strip()
    curses.noecho(); curses.curs_set(0)
    return val if val else default

def pick_list(stdscr, title, items, current, descs=None):
    """上下键选择列表，返回选中项"""
    idx = items.index(current) if current in items else 0
    while True:
        stdscr.clear(); draw_header(stdscr)
        S(stdscr, 4, 0, f"── {title} ", C_HEAD())
        for i, item in enumerate(items):
            attr = C_SEL() if i == idx else (C_ON() if item == current else 0)
            line = f"  {'▶ ' if i==idx else '  '}{item}"
            if descs and item in descs:
                line += f"  ({descs[item]})"
            S(stdscr, 5+i, 2, line, attr)
        S(stdscr, 5+len(items)+1, 0, "↑↓移动  Enter确认  q取消", C_HEAD())
        stdscr.refresh()
        k = stdscr.getch()
        if k in (curses.KEY_UP, ord('k')) and idx > 0: idx -= 1
        elif k in (curses.KEY_DOWN, ord('j')) and idx < len(items)-1: idx += 1
        elif k in (10, 13): return items[idx]
        elif k in (ord('q'), 27): return current

def toggle_bool(stdscr, label, current):
    items = ["开启", "关闭"]
    cur = "开启" if current else "关闭"
    r = pick_list(stdscr, label, items, cur)
    return r == "开启"

# ── config display ────────────────────────────────────────────────────────────

def draw_config(win, row):
    def kv(r, k, v, vc=None):
        S(win, row+r, 2, f"{k:<16}", C_HEAD())
        S(win, row+r, 18, str(v), vc or C_VAL())
    S(win, row, 0, "── 当前配置 ────────────────────────────────", C_HEAD())
    kv(1, "输入文件:",  state["source"] or "(未设置)", C_OFF() if not state["source"] else C_VAL())
    kv(2, "输出文件:",  state["out"] or "(自动)")
    kv(3, "预设:",      state["preset"])
    kv(4, "Lua版本:",   state["lua_version"])
    kv(5, "美化输出:",  "开" if state["pretty"] else "关", C_ON() if state["pretty"] else C_OFF())
    kv(6, "随机种子:",  state["seed"])
    kv(7, "命名方式:",  state["name_gen"])
    kv(8, "变量前缀:",  state["var_prefix"] or "(无)")
    kv(9, "水印:",      "开" if state["watermark"] else "关", C_ON() if state["watermark"] else C_OFF())
    steps_label = "自定义" if state["custom_steps"] is not None else "跟随预设"
    kv(10, "Steps:",      steps_label)
    kv(11, "AntiEnvLog:", "开" if state["anti_envlog"] else "关", C_ON() if state["anti_envlog"] else C_OFF())
    r = 12
    if state["watermark"]:
        kv(r,   "  内容:", state["wm_content"]); r+=1
        kv(r,   "  变量:", state["wm_var"]);     r+=1
    return row + r

# ── screens ───────────────────────────────────────────────────────────────────

def screen_files(stdscr):
    state["source"] = prompt(stdscr, "输入文件路径", state["source"])
    state["out"]    = prompt(stdscr, "输出文件路径 (留空=自动)", state["out"])

def screen_watermark(stdscr):
    state["watermark"] = toggle_bool(stdscr, "水印开关", state["watermark"])
    if state["watermark"]:
        state["wm_content"] = prompt(stdscr, "水印内容", state["wm_content"])
        state["wm_var"]     = prompt(stdscr, "水印变量名", state["wm_var"])

def screen_advanced(stdscr):
    state["lua_version"] = pick_list(stdscr, "Lua 版本  (Lua51=标准Lua5.1  LuaU=Roblox)", LUA_VERSIONS, state["lua_version"])
    state["name_gen"]    = pick_list(stdscr, "变量命名方式", NAME_GENS, state["name_gen"], NAME_GEN_DESC)
    stdscr.clear(); draw_header(stdscr)
    S(stdscr, 4, 0, "── 高级设置 ────────────────────────────────", C_HEAD())
    S(stdscr, 5, 2, "随机种子：影响混淆结果，0=每次不同", C_VAL())
    state["seed"] = int(prompt(stdscr, f"随机种子 [{state['seed']}]", str(state["seed"])) or state["seed"])
    S(stdscr, 7, 2, "变量前缀：生成变量名的前缀字符串", C_VAL())
    state["var_prefix"] = prompt(stdscr, f"变量前缀 [{state['var_prefix']}]", state["var_prefix"])
    state["pretty"] = toggle_bool(stdscr, "美化输出 (格式化代码，调试用)", state["pretty"])

def screen_steps(stdscr):
    """自定义 Steps 开关，上下移动，空格切换，支持重置为预设"""
    # 初始化：若无自定义则从当前预设加载
    if state["custom_steps"] is None:
        enabled = set(BUILTIN_STEPS.get(state["preset"], []))
    else:
        enabled = set(state["custom_steps"])

    idx = 0
    while True:
        stdscr.clear(); draw_header(stdscr)
        S(stdscr, 4, 0, "── 自定义 Steps ────────────────────────────", C_HEAD())
        for i, (name, desc) in enumerate(ALL_STEPS):
            on = name in enabled
            mark = "[✓]" if on else "[ ]"
            attr = C_SEL() if i == idx else (C_ON() if on else C_OFF())
            S(stdscr, 5+i, 2, f"{'▶ ' if i==idx else '  '}{mark} {name:<24} {desc}", attr)
        S(stdscr, 5+len(ALL_STEPS)+1, 0, "↑↓移动  空格切换  r重置为预设  Enter保存  q取消", C_HEAD())
        stdscr.refresh()
        k = stdscr.getch()
        if k in (curses.KEY_UP, ord('k')) and idx > 0: idx -= 1
        elif k in (curses.KEY_DOWN, ord('j')) and idx < len(ALL_STEPS)-1: idx += 1
        elif k == ord(' '):
            name = ALL_STEPS[idx][0]
            if name in enabled: enabled.discard(name)
            else: enabled.add(name)
        elif k == ord('r'):
            enabled = set(BUILTIN_STEPS.get(state["preset"], []))
            state["custom_steps"] = None
        elif k in (10, 13):
            # 按预设顺序保存
            order = [n for n,_ in ALL_STEPS]
            state["custom_steps"] = [n for n in order if n in enabled]
            break
        elif k in (ord('q'), 27):
            break

def screen_presets(stdscr):
    """自定义预设管理：保存当前配置为预设、加载、删除"""
    while True:
        stdscr.clear(); draw_header(stdscr)
        S(stdscr, 4, 0, "── 自定义预设 ──────────────────────────────", C_HEAD())
        items = ["保存当前配置为新预设"] + list(custom_presets.keys()) + ["← 返回"]
        idx = getattr(screen_presets, '_idx', 0)
        for i, item in enumerate(items):
            attr = C_SEL() if i == idx else (C_ON() if i == 0 else (C_OFF() if item == "← 返回" else 0))
            S(stdscr, 5+i, 2, f"{'▶ ' if i==idx else '  '}{item}", attr)
        S(stdscr, 5+len(items)+1, 0, "↑↓移动  Enter选择  d删除预设  q返回", C_HEAD())
        stdscr.refresh()
        k = stdscr.getch()
        if k in (curses.KEY_UP, ord('k')) and idx > 0: idx -= 1
        elif k in (curses.KEY_DOWN, ord('j')) and idx < len(items)-1: idx += 1
        elif k in (10, 13):
            sel = items[idx]
            if sel == "← 返回": break
            elif sel == "保存当前配置为新预设":
                name = prompt(stdscr, "预设名称")
                if name:
                    custom_presets[name] = {
                        "lua_version": state["lua_version"],
                        "pretty":      state["pretty"],
                        "seed":        state["seed"],
                        "name_gen":    state["name_gen"],
                        "var_prefix":  state["var_prefix"],
                        "watermark":   state["watermark"],
                        "wm_content":  state["wm_content"],
                        "wm_var":      state["wm_var"],
                        "custom_steps": state["custom_steps"],
                    }
                    save_custom_presets(custom_presets)
            else:
                # 加载预设
                p = custom_presets[sel]
                for k2 in ("lua_version","pretty","seed","name_gen","var_prefix","watermark","wm_content","wm_var","custom_steps"):
                    if k2 in p: state[k2] = p[k2]
                state["preset"] = sel
                break
        elif k == ord('d') and 0 < idx < len(items)-1:
            name = items[idx]
            del custom_presets[name]
            save_custom_presets(custom_presets)
            idx = max(0, idx-1)
        elif k in (ord('q'), 27): break
        screen_presets._idx = idx

# ── build & run ───────────────────────────────────────────────────────────────

def steps_to_lua(step_names):
    parts = []
    for name in step_names:
        s = STEP_DEFAULTS.get(name, {})
        def lua_val(v):
            if isinstance(v, bool): return "true" if v else "false"
            if isinstance(v, str):  return json.dumps(v)
            return str(v)
        settings = ", ".join(f"{k} = {lua_val(v)}" for k,v in s.items())
        parts.append(f'{{ Name = "{name}", Settings = {{ {settings} }} }}')
    return "{\n" + ",\n".join(f"    {p}" for p in parts) + "\n  }"

def build_config():
    if state["custom_steps"] is not None:
        step_names = list(state["custom_steps"])
    else:
        step_names = list(BUILTIN_STEPS.get(state["preset"], []))
    if state["watermark"]:
        step_names.insert(0, "__watermark__")

    parts = []
    for name in step_names:
        if name == "__watermark__":
            parts.append(f'{{ Name = "Watermark", Settings = {{ Content = {json.dumps(state["wm_content"])}, CustomVariable = {json.dumps(state["wm_var"])} }} }}')
        else:
            s = STEP_DEFAULTS.get(name, {})
            def lua_val(v):
                if isinstance(v, bool): return "true" if v else "false"
                if isinstance(v, str):  return json.dumps(v)
                return str(v)
            settings = ", ".join(f"{k} = {lua_val(v)}" for k,v in s.items())
            parts.append(f'{{ Name = "{name}", Settings = {{ {settings} }} }}')

    steps_lua = "{\n" + ",\n".join(f"    {p}" for p in parts) + "\n  }"
    return (f"return {{\n"
            f"  LuaVersion = {json.dumps(state['lua_version'])},\n"
            f"  VarNamePrefix = {json.dumps(state['var_prefix'])},\n"
            f"  NameGenerator = {json.dumps(state['name_gen'])},\n"
            f"  PrettyPrint = {'true' if state['pretty'] else 'false'},\n"
            f"  Seed = {state['seed']},\n"
            f"  Steps = {steps_lua},\n"
            f"}}\n")

def run_obfuscation(stdscr):
    stdscr.clear(); draw_header(stdscr)
    if not state["source"] or not os.path.isfile(state["source"]):
        S(stdscr, 4, 0, f"✗ 文件不存在: {state['source']}", C_OFF())
        stdscr.refresh(); stdscr.getch(); return
    out = state["out"] or (
        state["source"][:-4] + ".obfuscated.lua" if state["source"].endswith(".lua")
        else state["source"] + ".obfuscated.lua")
    S(stdscr, 4, 0, "混淆中...", C_VAL()); stdscr.refresh()
    cfg_lua = build_config()

    # 若开启 anti_envlog，将代码插入源码前，写入临时文件作为混淆输入
    src_path = state["source"]
    tmp_src = None
    if state["anti_envlog"]:
        with open(state["source"], "r", encoding="utf-8") as f: original = f.read()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".lua", delete=False, encoding="utf-8") as f:
            f.write(ANTI_ENVLOG_CODE + original)
            tmp_src = f.name
        src_path = tmp_src

    with tempfile.NamedTemporaryFile(mode="w", suffix=".lua", delete=False) as f:
        f.write(cfg_lua); cfg_path = f.name
    try:
        result = subprocess.run(
            ["lua", "cli.lua", src_path, "--config", cfg_path, "--out", out],
            cwd=SCRIPT_DIR, capture_output=True, text=True)
        if result.returncode == 0:
            S(stdscr, 5, 0, f"✓ 完成 → {out}", C_ON())
        else:
            S(stdscr, 5, 0, "✗ 错误:", C_OFF())
            for i, line in enumerate((result.stderr or result.stdout).splitlines()[:10]):
                S(stdscr, 6+i, 2, line, C_OFF())
    finally:
        os.unlink(cfg_path)
        if tmp_src: os.unlink(tmp_src)
    stdscr.refresh(); stdscr.getch()

# ── main menu ─────────────────────────────────────────────────────────────────

MENU = [
    ("设置输入/输出文件",   screen_files),
    ("选择预设",            lambda s: None),
    ("自定义 Steps",        screen_steps),
    ("水印设置",            screen_watermark),
    ("AntiEnvLog",          lambda s: None),   # handled inline
    ("高级设置",            screen_advanced),
    ("自定义预设管理",      screen_presets),
    ("▶ 执行混淆",          run_obfuscation),
    ("退出",                None),
]

def main(stdscr):
    curses.curs_set(0); init_colors()
    idx = 0
    all_presets = PRESETS + list(custom_presets.keys())

    while True:
        all_presets = ["Minify","Weak","Medium","Strong"] + list(custom_presets.keys())
        stdscr.clear(); draw_header(stdscr)
        cfg_end = draw_config(stdscr, 4)
        S(stdscr, cfg_end, 0, "── 菜单 ────────────────────────────────────", C_HEAD())
        for i, (label, _) in enumerate(MENU):
            is_run  = label.startswith("▶")
            is_quit = label == "退出"
            if i == idx:
                attr = C_SEL()
            elif is_run:
                attr = C_ON() | curses.A_BOLD
            elif is_quit:
                attr = C_OFF()
            else:
                attr = 0
            S(stdscr, cfg_end+1+i, 2, f"{'▶ ' if i==idx else '  '}{label}", attr)
        S(stdscr, cfg_end+1+len(MENU)+1, 0, "↑↓移动  Enter确认", C_HEAD())
        stdscr.refresh()

        k = stdscr.getch()
        if k in (curses.KEY_UP, ord('k')) and idx > 0: idx -= 1
        elif k in (curses.KEY_DOWN, ord('j')) and idx < len(MENU)-1: idx += 1
        elif k in (10, 13):
            label, fn = MENU[idx]
            if label == "退出": break
            elif label == "选择预设":
                state["preset"] = pick_list(stdscr, "选择预设", all_presets, state["preset"])
                state["custom_steps"] = None
            elif label == "AntiEnvLog":
                state["anti_envlog"] = toggle_bool(stdscr, "AntiEnvLog 防环境检测", state["anti_envlog"])
            elif fn:
                fn(stdscr)

if __name__ == "__main__":
    curses.wrapper(main)
